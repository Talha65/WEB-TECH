<?php 
	

	if(isset($_POST['submit'])){

		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$name = $firstName . ' ' . $lastName;
		$email = $_POST['email'];
		$pass = $_POST['password'];
		$cpass = $_POST['cpassword'];
	    $day = $_POST['day'];
		$month = $_POST['month'];
		$year = $_POST['year'];
		$gender = $_POST['gender'];
		$phone = $_POST['phone'];

		//first name check
		if($firstName != ""){
			if ((strpos($firstName,'0')!==false) || (strpos($firstName,'1')!==false) || (strpos($firstName,'2')!==false) || (strpos($firstName,'3')!==false) || (strpos($firstName,'4')!==false) || (strpos($firstName,'5')!==false) || (strpos($firstName,'6')!==false) || (strpos($firstName,'7')!==false) || (strpos($firstName,'8')!==false) || (strpos($firstName,'9')!==false))  {

	    		echo "Invalid First Name <br>" ;
			}else{
				
				if(strpos($firstName, ',')!=false ||strpos($firstName, '.')!=false ||strpos($firstName, '+')!=false||strpos($firstName, '*')!=false ||strpos($firstName, '/')!=false ||strpos($firstName, '!')!=false ||strpos($firstName, '@')!=false){
	    			echo "Invalid First Name <br>" ;

				}else{
					echo "First Name: ".$firstName;
				}
				
			}

		}else{
			echo "Invalid First Name <br>";
		}

		

		//last name check
		if($lastName != ""){
			if((strpos($lastName, '0')!==false) || (strpos($lastName,'1')!==false) || (strpos($lastName,'2')!==false) || (strpos($lastName,'3')!==false) || (strpos($lastName,'4')!==false) || (strpos($lastName,'5')!==false) || (strpos($lastName,'6')!==false) || (strpos($lastName,'7')!==false) || (strpos($lastName,'8')!==false) || (strpos($lastName,'9')!==false)){

				echo "Invalid Last Name <br>" ;

			}else{
				if(strpos($lastName, ',')!=false ||strpos($lastName, '.')!=false ||strpos($lastName, '+')!=false ||strpos($lastName, '*')!=false ||strpos($lastName, '/')!=false ||strpos($lastName, '!')!=false ||strpos($lastName, '@')!=false){
	    			echo "Invalid Last Name <br>" ;

				}else{
					echo "Last Name: ".$lastName;
				}
			}
		}else{
			echo "Invalid Last Name <br>" ;
		}


		//fullname check
		if(str_word_count($name)>=2){
			echo "Name is ok <br>";
		}else{
			echo "Name is less than two words <br>";
		}


		//password check
		if ($pass != "" && $cpass != "" && ($pass == $cpass)) {
			echo "Password ok <br>" ;

		}else{
			echo "Password Didn't Match <br>" ;
		}

		
		//email check
		if ($email != "") {

			if(strpos($email, '@')){

				echo "Email ok <br>" ;
			}else{
				echo "  ***Invalid Email  <br>";
			}
		}else{
			echo "Invalid Email <br>";
		}

		//gender check
		if ($gender != "") {
			echo "Gender ok <br>" ;
		}else{
			echo "Select Gender <br>";
		}

		//birthday check
		if ($day!="" && $month!="" && $year!="") {
			
			if (($day>=1) && ($day<=31) && ($month>=1) && ($month<=12) && ($year>=1900) && ($year<= 2016)) {
				echo "Birthday ok <br>" ;
			}

		}else{
			echo "Select Birthday Date <br>";
		}

		//cellphone check

		if( strlen($phone)>=11){
			echo "Number is ok <br>";
		}else{
			echo "Number is less than 11 digit <br>";
		}


	}else{
		header('location:registration.html');
	}
	


 ?>	
